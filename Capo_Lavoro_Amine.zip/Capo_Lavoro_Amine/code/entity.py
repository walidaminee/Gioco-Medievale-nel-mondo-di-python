import pygame
from math import sin

class Entity(pygame.sprite.Sprite):
    def __init__(self, groups):
        """
        Inizializza un'entità di base.
        
        Parametri:
        - groups: I gruppi di sprite a cui l'entità appartiene.
        """
        super().__init__(groups)
        self.frame_index = 0
        self.animation_speed = 0.15
        self.direction = pygame.math.Vector2()

    def move(self, speed):
        """
        Muove l'entità nella direzione specificata e gestisce le collisioni.
        
        Parametri:
        - speed: La velocità di movimento dell'entità.
        """
        if self.direction.magnitude() != 0:
            self.direction = self.direction.normalize()

        self.hitbox.x += self.direction.x * speed
        self.collision('horizontal')
        self.hitbox.y += self.direction.y * speed
        self.collision('vertical')
        self.rect.center = self.hitbox.center

    def collision(self, direction):
        """
        Gestisce le collisioni dell'entità con gli ostacoli.
        
        Parametri:
        - direction: La direzione della collisione ('horizontal' o 'vertical').
        """
        if direction == 'horizontal':
            for sprite in self.obstacle_sprites:
                if sprite.hitbox.colliderect(self.hitbox):
                    if self.direction.x > 0:  # muovendosi a destra
                        self.hitbox.right = sprite.hitbox.left
                    if self.direction.x < 0:  # muovendosi a sinistra
                        self.hitbox.left = sprite.hitbox.right

        if direction == 'vertical':
            for sprite in self.obstacle_sprites:
                if sprite.hitbox.colliderect(self.hitbox):
                    if self.direction.y > 0:  # muovendosi verso il basso
                        self.hitbox.bottom = sprite.hitbox.top
                    if self.direction.y < 0:  # muovendosi verso l'alto
                        self.hitbox.top = sprite.hitbox.bottom

    def wave_value(self):
        """
        Genera un valore oscillante tra 0 e 255 per effetti visivi, come il lampeggiamento.
        
        Ritorna:
        - Un valore di trasparenza (0 o 255) per creare un effetto di lampeggiamento.
        """
        value = sin(pygame.time.get_ticks())
        if value >= 0:
            return 255
        else:
            return 0
