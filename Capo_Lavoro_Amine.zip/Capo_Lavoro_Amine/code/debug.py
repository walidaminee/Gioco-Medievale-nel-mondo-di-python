import pygame

# Inizializza il modulo pygame
pygame.init()

# Configura il font da utilizzare per il debug
font = pygame.font.Font(None, 30)

def debug(info, y=10, x=10):
    """
    Funzione di debug per visualizzare informazioni sullo schermo.

    Parametri:
    - info: L'informazione da visualizzare (può essere di qualsiasi tipo, verrà convertita in stringa).
    - y: La coordinata Y dove verrà posizionata l'informazione sullo schermo (default: 10).
    - x: La coordinata X dove verrà posizionata l'informazione sullo schermo (default: 10).
    """
    # Ottiene la superficie di visualizzazione corrente
    display_surface = pygame.display.get_surface()

    # Crea una superficie per il testo del debug
    debug_surf = font.render(str(info), True, 'White')

    # Ottiene il rettangolo del testo per posizionarlo correttamente
    debug_rect = debug_surf.get_rect(topleft=(x, y))

    # Disegna un rettangolo nero dietro il testo per migliorare la leggibilità
    pygame.draw.rect(display_surface, 'Black', debug_rect)

    # Disegna il testo sulla superficie di visualizzazione
    display_surface.blit(debug_surf, debug_rect)
