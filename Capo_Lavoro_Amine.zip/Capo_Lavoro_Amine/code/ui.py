import pygame
from settings import *

class UI:
    def __init__(self):
        """Classe per la gestione dell'interfaccia utente (UI).

        Attributes:
            display_surface (pygame.Surface): Superficie di visualizzazione della UI.
            font (pygame.font.Font): Font utilizzato per il testo della UI.
            health_bar_rect (pygame.Rect): Rettangolo della barra della salute.
            energy_bar_rect (pygame.Rect): Rettangolo della barra dell'energia.
            weapon_graphics (list): Lista delle immagini delle armi.
            magic_graphics (list): Lista delle immagini della magia.
        """
        # Generale
        self.display_surface = pygame.display.get_surface()
        self.font = pygame.font.Font(UI_FONT, UI_FONT_SIZE)

        # Setup delle barre
        self.health_bar_rect = pygame.Rect(10, 10, HEALTH_BAR_WIDTH, BAR_HEIGHT)
        self.energy_bar_rect = pygame.Rect(10, 34, ENERGY_BAR_WIDTH, BAR_HEIGHT)

        # Converti il dizionario delle armi
        self.weapon_graphics = []
        for weapon in weapon_data.values():
            path = weapon['graphic']
            weapon_img = pygame.image.load(path).convert_alpha()
            self.weapon_graphics.append(weapon_img)

        # Converti il dizionario della magia
        self.magic_graphics = []
        for magic in magic_data.values():
            magic_img = pygame.image.load(magic['graphic']).convert_alpha()
            self.magic_graphics.append(magic_img)

    def show_bar(self, current, max_amount, bg_rect, color):
        """Mostra una barra di valore sulla UI.

        Args:
            current (float): Valore corrente.
            max_amount (float): Valore massimo.
            bg_rect (pygame.Rect): Rettangolo di sfondo della barra.
            color (tuple): Colore della barra.
        """
        # Disegna lo sfondo
        pygame.draw.rect(self.display_surface, UI_BG_COLOR, bg_rect)

        # Converti lo stato in pixel
        ratio = current / max_amount
        current_width = bg_rect.width * ratio
        current_rect = bg_rect.copy()
        current_rect.width = current_width

        # Disegna la barra
        pygame.draw.rect(self.display_surface, color, current_rect)
        pygame.draw.rect(self.display_surface, UI_BORDER_COLOR, bg_rect, 3)

    def show_exp(self, exp):
        """Mostra l'esperienza sulla UI.

        Args:
            exp (int): Punti esperienza.
        """
        text_surf = self.font.render(str(int(exp)), False, TEXT_COLOR)
        x = self.display_surface.get_size()[0] - 20
        y = self.display_surface.get_size()[1] - 20
        text_rect = text_surf.get_rect(bottomright=(x, y))

        pygame.draw.rect(self.display_surface, UI_BG_COLOR, text_rect.inflate(20, 20))
        self.display_surface.blit(text_surf, text_rect)
        pygame.draw.rect(self.display_surface, UI_BORDER_COLOR, text_rect.inflate(20, 20), 3)

    def selection_box(self, left, top, has_switched):
        """Mostra una casella di selezione sulla UI.

        Args:
            left (int): Posizione sinistra della casella.
            top (int): Posizione superiore della casella.
            has_switched (bool): Indica se è stato cambiato.

        Returns:
            pygame.Rect: Rettangolo della casella.
        """
        bg_rect = pygame.Rect(left, top, ITEM_BOX_SIZE, ITEM_BOX_SIZE)
        pygame.draw.rect(self.display_surface, UI_BG_COLOR, bg_rect)
        if has_switched:
            pygame.draw.rect(self.display_surface, UI_BORDER_COLOR_ACTIVE, bg_rect, 3)
        else:
            pygame.draw.rect(self.display_surface, UI_BORDER_COLOR, bg_rect, 3)
        return bg_rect

    def weapon_overlay(self, weapon_index, has_switched):
        """Mostra l'arma selezionata sulla UI.

        Args:
            weapon_index (int): Indice dell'arma selezionata.
            has_switched (bool): Indica se è stato cambiato.
        """
        bg_rect = self.selection_box(10, 630, has_switched)
        weapon_surf = self.weapon_graphics[weapon_index]
        weapon_rect = weapon_surf.get_rect(center=bg_rect.center)

        self.display_surface.blit(weapon_surf, weapon_rect)

    def magic_overlay(self, magic_index, has_switched):
        """Mostra la magia selezionata sulla UI.

        Args:
            magic_index (int): Indice della magia selezionata.
            has_switched (bool): Indica se è stato cambiato.
        """
        bg_rect = self.selection_box(80, 635, has_switched)
        magic_surf = self.magic_graphics[magic_index]
        magic_rect = magic_surf.get_rect(center=bg_rect.center)

        self.display_surface.blit(magic_surf, magic_rect)

    def display(self, player):
        """Mostra tutti gli elementi della UI.

        Args:
            player (Player): Giocatore attuale.
        """
        self.show_bar(player.health, player.stats['health'], self.health_bar_rect, HEALTH_COLOR)
        self.show_bar(player.energy, player.stats['energy'], self.energy_bar_rect, ENERGY_COLOR)

        self.show_exp(player.exp)

        self.weapon_overlay(player.weapon_index, not player.can_switch_weapon)
        self.magic_overlay(player.magic_index, not player.can_switch_magic)
