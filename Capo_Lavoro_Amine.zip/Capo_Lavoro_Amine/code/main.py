import pygame, sys
from settings import *
from level import Level

class Game:
    def __init__(self):
        # Setup generale per l'inizializzazione del gioco
        pygame.init()  # Inizializza tutti i moduli di Pygame
        self.screen = pygame.display.set_mode((WIDTH, HEIGTH))  # Crea la finestra di gioco con le dimensioni specificate
        pygame.display.set_caption('Zelda')  # Imposta il titolo della finestra
        self.clock = pygame.time.Clock()  # Crea un oggetto Clock per controllare il framerate

        self.level = Level()  # Inizializza il livello del gioco

        # Caricamento e configurazione del suono principale del gioco
        main_sound = pygame.mixer.Sound('../audio/main.ogg')  # Carica il file audio principale
        main_sound.set_volume(0.5)  # Imposta il volume del suono a metà
        main_sound.play(loops=-1)  # Riproduce il suono in loop infinito
    
    def run(self):
        while True:
            for event in pygame.event.get():  # Gestione degli eventi
                if event.type == pygame.QUIT:  # Controlla se l'utente ha chiuso la finestra
                    pygame.quit()  # Termina Pygame
                    sys.exit()  # Esce dal programma
                if event.type == pygame.KEYDOWN:  # Controlla se un tasto è stato premuto
                    if event.key == pygame.K_m:  # Controlla se il tasto 'M' è stato premuto
                        self.level.toggle_menu()  # Attiva/disattiva il menu del livello

            self.screen.fill(WATER_COLOR)  # Riempie lo schermo con il colore dell'acqua
            self.level.run()  # Esegue il ciclo principale del livello
            pygame.display.update()  # Aggiorna il display
            self.clock.tick(FPS)  # Mantiene il framerate costante

if __name__ == '__main__':
    game = Game()  # Crea un'istanza del gioco
    game.run()  # Avvia il gioco
